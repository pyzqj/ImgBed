const s="/image.svg";export{s as _};

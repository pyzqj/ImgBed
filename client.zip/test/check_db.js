/**
 * 检查数据库完整性的脚本
 */
const initSqlJs = require('sql.js');
const fs = require('fs');
const path = require('path');

async function checkDB() {
  const SQL = await initSqlJs();
  const dbPath = path.join(__dirname, '../data/imgbed.db');
  
  if (!fs.existsSync(dbPath)) {
    console.log('数据库文件不存在');
    return;
  }

  const data = fs.readFileSync(dbPath);
  console.log('数据库文件大小:', data.length, 'bytes');

  try {
    const db = new SQL.Database(data);
    
    // 检查表结构
    const tables = db.exec("SELECT name FROM sqlite_master WHERE type='table'");
    console.log('表列表:', tables.length > 0 ? tables[0].values.map(r => r[0]) : '无');

    // 检查用户
    try {
      const users = db.exec('SELECT id, username FROM users');
      console.log('用户:', users.length > 0 ? users[0].values : '无');
    } catch (e) {
      console.log('读取用户表失败:', e.message);
    }

    // 检查配置
    try {
      const configs = db.exec('SELECT platform FROM configs');
      console.log('已配置平台:', configs.length > 0 ? configs[0].values.map(r => r[0]) : '无');
    } catch (e) {
      console.log('读取配置表失败:', e.message);
    }

    // 检查文件数量
    try {
      const fileCount = db.exec('SELECT COUNT(*) as count FROM files');
      console.log('文件数量:', fileCount[0].values[0][0]);
    } catch (e) {
      console.log('读取文件表失败:', e.message);
    }

    console.log('数据库完整性检查通过');
  } catch (e) {
    console.error('数据库损坏:', e.message);
    
    // 尝试恢复 - 备份并重建
    console.log('\n尝试恢复...');
    const backupPath = dbPath + '.corrupted';
    fs.copyFileSync(dbPath, backupPath);
    console.log('已备份损坏的数据库到:', backupPath);
  }
}

checkDB().catch(console.error);
